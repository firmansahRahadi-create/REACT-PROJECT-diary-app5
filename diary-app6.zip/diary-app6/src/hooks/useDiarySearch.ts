import { useEffect, useMemo, useState } from 'react';
import { DiaryEntry } from '../context/DiaryContext';

export function useDiarySearch(entries: DiaryEntry[]) {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [mood, setMood] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 350);

    return () => {
      clearTimeout(timer);
    };
  }, [query]);

  const filteredEntries = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();
    
    return entries.filter((entry) => {
      // Cek kecocokan query text
      const matchQuery = !q || 
        entry.title.toLowerCase().includes(q) ||
        entry.preview.toLowerCase().includes(q) ||
        entry.date.toLowerCase().includes(q);
        
      // Cek kecocokan mood
      const matchMood = !mood || entry.mood === mood;
      
      return matchQuery && matchMood;
    });
  }, [entries, debouncedQuery, mood]);

  const resetFilter = () => {
    setQuery('');
    setMood('');
  };

  return {
    query,
    setQuery,
    mood,
    setMood,
    filteredEntries,
    resultCount: filteredEntries.length,
    resetFilter,
  };
}
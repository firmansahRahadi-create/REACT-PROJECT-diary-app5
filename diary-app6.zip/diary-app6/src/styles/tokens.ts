export const COLORS = {
  surface: 'rgba(30, 41, 59, 0.7)', // Efek semi-transparan (Glassmorphism)
  background: '#0F172A', // Slate 900 (Dark background)
  border: 'rgba(255, 255, 255, 0.15)', // Border tipis putih
  text: '#F8FAFC',
  muted: '#94A3B8',
  accent: '#3B82F6', // Blue 500
  danger: '#EF4444',
};

export const SPACE = {
  s: 8,
  m: 12,
  l: 16,
  xl: 24,
};

export const RADIUS = {
  card: 16,
};

export const TYPO = {
  h1: 28,
  title: 18,
  body: 14,
  caption: 12,
};
# Diary App - Praktikum Mobile multiflatfom Pertemuan 6

Proyek ini adalah aplikasi catatan harian (Diary App) berbasis **React Native** dan **Expo Router** yang mengimplementasikan penggunaan *State* dan *React Hooks* secara mendalam. Fitur utama aplikasi ini mencakup penambahan diary, pencarian (dengan sistem *debounce*), filter berdasarkan *mood*, serta sinkronisasi status favorit (like) secara global menggunakan *Context*.


* **Nama** : Firmansah Rahadi

* **NIM**  : 2430511033

* **Kelas**: 5A

  


## 🚀 Cara Menjalankan Project

Ikuti langkah-langkah berikut untuk menjalankan aplikasi di komputer/laptop Anda:

1. **Persiapan**
   Pastikan Anda sudah menginstal **Node.js** dan aplikasi **Expo Go** di *smartphone* Anda (atau menggunakan Android Studio Emulator).

2. **Instalasi Dependency**
   Buka terminal/command prompt, arahkan ke dalam folder proyek (`diary-app6`), lalu jalankan perintah:

   ```
   npm install
   
   ```

   *(Catatan: pastikan `expo-router` dan `@expo/vector-icons` sudah terinstal).*

3. **Menjalankan Server Expo**
   Mulai server lokal Expo dengan perintah (opsi `-c` digunakan untuk membersihkan *cache* agar file baru langsung terbaca):

   ```
   npx expo start -c
   
   ```

4. **Buka Aplikasi**

   * **Device Fisik**: Buka aplikasi Expo Go di HP Anda dan *scan QR code* yang muncul di terminal.

   * **Emulator**: Tekan tombol `a` pada keyboard di terminal untuk membuka via Android Emulator.

## 🪝 Tabel Penjelasan 5 React Hooks Utama

Sesuai dengan instruksi tugas praktikum, berikut adalah analisis dari lima React Hooks yang digunakan pada proyek Diary App ini:

| No. | Nama Hook | Penjelasan |
|---|---|---|
| 1 | `useState` | Mengelola data sementara pada komponen, seperti teks pencarian (`query`), pilihan `mood`, dan isi formulir. Hook ini menerima nilai awal dan mengembalikan nilai state beserta fungsi untuk mengubahnya. |
| 2 | `useEffect` | Menjalankan efek samping ketika nilai tertentu berubah. Pada `useDiarySearch`, hook ini membuat jeda pencarian (*debounce*) selama 350 ms. Fungsi *cleanup* membatalkan timer sebelumnya saat pengguna masih mengetik. |
| 3 | `useMemo` | Menyimpan hasil perhitungan agar tidak dihitung ulang tanpa perlu. Hook ini digunakan untuk memfilter data diary berdasarkan `entries`, `debouncedQuery`, dan `mood`. |
| 4 | `useContext` | Memungkinkan beberapa halaman mengakses data dan fungsi bersama dari `DiaryContext`. Home, Create, Detail, dan Favorites dapat membaca atau mengubah data diary serta status favorit. |
| 5 | `useCallback` | Menyimpan referensi fungsi agar tetap stabil selama dependensinya belum berubah. Hook ini digunakan, misalnya, untuk fungsi dengan dependensi `[router]` atau `[resetFilter]`, termasuk fungsi yang diteruskan ke komponen seperti `FlatList`. |

*Dibuat untuk memenuhi Tugas Praktikum Mata Kuliah Mobile Programming - Universitas Muhammadiyah Sukabumi.*
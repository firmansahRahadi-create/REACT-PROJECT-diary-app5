import { Tabs } from 'expo-router';
// Import library ikon bawaan Expo
import { Ionicons } from '@expo/vector-icons';

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        // Styling warna Tab Bar agar serasi dengan tema gelap (Dark Theme)
        tabBarActiveTintColor: '#3B82F6', // Warna biru saat aktif (COLORS.accent)
        tabBarInactiveTintColor: '#94A3B8', // Warna abu-abu saat tidak aktif (COLORS.muted)
        tabBarStyle: {
          backgroundColor: '#1E293B', // Warna background tab bar
          borderTopColor: 'rgba(255, 255, 255, 0.15)', // Garis atas tipis
        },
        headerStyle: {
          backgroundColor: '#0F172A', // Warna background header atas
        },
        headerTintColor: '#F8FAFC', // Warna teks header atas
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home" size={size} color={color} />
          ),
        }}
      />
      
      <Tabs.Screen
        name="create"
        options={{
          title: 'Tambah',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="add-circle" size={size} color={color} />
          ),
        }}
      />

      <Tabs.Screen
        name="favorites"
        options={{
          title: 'Favorit',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="heart" size={size} color={color} />
          ),
        }}
      />
      
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Pengaturan',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="settings" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
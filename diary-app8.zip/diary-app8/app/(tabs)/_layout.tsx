import { Tabs } from "expo-router";

export default function TabLayout() {
  return (
    <Tabs screenOptions={{ headerShown: false }}>
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarLabel: "Home",
          tabBarAccessibilityLabel: "Halaman Home",
        }}
      />
      <Tabs.Screen
        name="create"
        options={{
          title: "Tambah Diary",
          tabBarLabel: "Tambah",
          tabBarAccessibilityLabel: "Tambah diary",
        }}
      />
      <Tabs.Screen
        name="favorites"
        options={{
          title: "Favorite",
          tabBarLabel: "Favorite",
          tabBarAccessibilityLabel: "Daftar favorite",
        }}
      />
    </Tabs>
  );
}

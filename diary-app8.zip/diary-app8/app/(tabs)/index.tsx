import { useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import DiaryCard from "../../src/components/DiaryCard";
import { toggleFavorite } from "../../src/features/diary/diarySlice";
import { useAppDispatch, useAppSelector } from "../../src/store/hooks";
import { COLORS, RADIUS, SPACE, TYPO } from "../../src/styles/tokens";

const MOOD_FILTERS = ["Semua", "😊", "🚀", "📖", "😴"];

export default function HomeScreen() {
  const router = useRouter();
  const dispatch = useAppDispatch();

  const [selectedMood, setSelectedMood] = useState("Semua");

  const entries = useAppSelector((state) => state.diary.entries);
  const totalDiary = useAppSelector((state) => state.diary.entries.length);
  const totalFavorite = useAppSelector(
    (state) => state.diary.entries.filter((item) => item.liked).length
  );

  const filteredEntries = useMemo(() => {
    if (selectedMood === "Semua") return entries;
    return entries.filter((item) => item.mood === selectedMood);
  }, [entries, selectedMood]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Buku Harian</Text>
      <Text style={styles.counter}>
        Total Diary: {totalDiary} • Favorite: {totalFavorite}
      </Text>

      <View style={styles.filterRow}>
        {MOOD_FILTERS.map((mood) => {
          const active = selectedMood === mood;
          return (
            <Pressable
              key={mood}
              onPress={() => setSelectedMood(mood)}
              style={[styles.filterChip, active && styles.filterChipActive]}
            >
              <Text
                style={[styles.filterText, active && styles.filterTextActive]}
              >
                {mood}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <FlatList
        data={filteredEntries}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={
          filteredEntries.length === 0 ? styles.emptyList : undefined
        }
        renderItem={({ item }) => (
          <DiaryCard
            title={item.title}
            date={item.date}
            preview={item.preview}
            mood={item.mood}
            liked={item.liked}
            onToggleFavorite={() => dispatch(toggleFavorite({ id: item.id }))}
            onPress={() =>
              router.push({
                pathname: "/detail/[id]",
                params: {
                  id: String(item.id),
                },
              })
            }
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <Text style={styles.emptyTitle}>
              {entries.length === 0
                ? "Belum Ada Catatan Diary"
                : `Tidak Ada Diary dengan Mood ${selectedMood}`}
            </Text>
            <Text style={styles.emptyDesc}>
              {entries.length === 0
                ? "Tekan tab Tambah di bawah untuk mulai menulis catatan harian pertamamu."
                : "Pilih filter mood lain atau tekan Semua untuk melihat seluruh diary."}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: SPACE.l,
    backgroundColor: COLORS.background,
  },
  header: {
    fontSize: TYPO.h1,
    fontWeight: "700",
    color: COLORS.text,
  },
  counter: {
    color: COLORS.muted,
    marginBottom: SPACE.m,
  },
  filterRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: SPACE.s,
    marginBottom: SPACE.m,
  },
  filterChip: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  filterChipActive: {
    backgroundColor: COLORS.accent,
    borderColor: COLORS.accent,
  },
  filterText: {
    fontSize: TYPO.body,
    color: COLORS.text,
    fontWeight: "600",
  },
  filterTextActive: {
    color: "#FFFFFF",
  },
  emptyList: {
    flexGrow: 1,
    justifyContent: "center",
  },
  emptyBox: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.card,
    padding: SPACE.xl,
    alignItems: "center",
  },
  emptyTitle: {
    fontSize: TYPO.title,
    fontWeight: "700",
    color: COLORS.text,
    marginBottom: SPACE.s,
    textAlign: "center",
  },
  emptyDesc: {
    fontSize: TYPO.body,
    color: COLORS.muted,
    textAlign: "center",
    lineHeight: 20,
  },
});
# Diary App

Aplikasi diary sederhana berbasis Expo, React Native, dan Redux Toolkit.

## Fitur

- Membuat, melihat, mengubah, dan menghapus diary.
- Menandai favorite dan menghapus semua status favorite.
- Memfilter diary berdasarkan mood.
- Menampilkan total diary dan total favorite.
- Memvalidasi judul minimal 3 karakter dan isi diary wajib diisi.

## Perbedaan jenis state

- **Local state** disimpan di komponen yang menggunakannya, misalnya teks judul,
  isi, mood yang dipilih, atau filter mood sementara pada layar. State ini
  digunakan untuk mengatur tampilan dan input lokal.
- **Global Redux state** berada di Redux store agar dapat dibaca dan diubah oleh
  banyak layar. Pada aplikasi ini, daftar diary dan status favorite berada di
  Redux sehingga Home, Detail, Edit, dan Favorites menampilkan data yang sama.
- **Persistent database** menyimpan data secara permanen di media penyimpanan
  seperti database lokal atau server, sehingga data dapat dimuat kembali setelah
  aplikasi ditutup atau perangkat dimulai ulang. Aplikasi ini belum memakai
  persistent database; Redux state saat ini hanya hidup selama aplikasi berjalan
  dan akan kembali ke data awal setelah aplikasi dimulai ulang.

## AF. Pertanyaan Diskusi

1. **Mengapa isi `TextInput` tidak harus disimpan di Redux?**  
   Isi input biasanya hanya dibutuhkan oleh satu form selama pengguna mengetik.
   Local state dengan `useState` lebih sederhana dan menghindari update global
   untuk setiap perubahan karakter. Data dikirim ke Redux saat form disimpan.

2. **Apa perbedaan `dispatch(action)` dengan `setState()`?**  
   `setState()` memperbarui state lokal sebuah komponen. `dispatch(action)`
   mengirim action ke Redux Store; reducer memprosesnya dan memperbarui global
   state yang dapat digunakan oleh banyak komponen.

3. **Apa fungsi reducer?**  
   Reducer menentukan state berikutnya berdasarkan state saat ini dan action
   yang diterima. Reducer sebaiknya hanya berisi logika perubahan state dan
   tidak melakukan efek samping seperti mengakses jaringan.

4. **Mengapa Redux Store disebut *single source of truth*?**  
   Karena data global disimpan pada satu Store terpusat, bukan disalin dan
   dikelola terpisah di banyak screen. Screen membaca data yang sama dari sumber
   tersebut.

5. **Apa yang terjadi jika dua screen membaca state diary yang sama?**  
   Keduanya menampilkan data dari Store yang sama. Ketika action mengubah data
   diary, screen yang memilih bagian state tersebut akan menerima nilai terbaru
   dan dirender ulang.

6. **Apa perbedaan action dan reducer?**  
   Action adalah objek yang menjelaskan kejadian atau perubahan yang diminta,
   biasanya berisi `type` dan `payload`. Reducer adalah fungsi yang menentukan
   bagaimana state berubah sebagai respons terhadap action itu.

7. **Mengapa Redux Toolkit diperkenalkan dibanding Redux klasik?**  
   Redux Toolkit mengurangi boilerplate dan menyatukan pembuatan reducer serta
   action melalui `createSlice`. `configureStore` juga memberi konfigurasi
   standar, middleware, dan dukungan Redux DevTools.

8. **Apakah Redux dapat menggantikan MySQL?**  
   Tidak. Redux menyimpan state di memori aplikasi dan bukan database persisten;
   data dapat hilang saat aplikasi dimulai ulang. MySQL menyimpan data secara
   persisten di database. Redux dapat mengelola salinan data di sisi aplikasi
   yang diperoleh dari database atau API.

9. **Kapan Context API sudah cukup dan kapan Redux lebih sesuai?**  
   Context API cukup untuk nilai global yang sederhana dan jarang berubah,
   seperti tema. Redux lebih sesuai saat state kompleks, sering berubah,
   digunakan banyak screen, atau memerlukan alur action dan debugging yang
   terstruktur.

10. **Apa keuntungan typed hooks pada project TypeScript?**  
    Typed hooks seperti `useAppSelector` dan `useAppDispatch` menghubungkan
    penggunaan hooks dengan tipe `RootState` dan `AppDispatch`. TypeScript dapat
    membantu memeriksa selector, payload action, dan hasil dispatch saat
    pengembangan.

## Menjalankan aplikasi

```bash
npm install
npx expo start
```
